# Aplikasi Rental Barang

Aplikasi web CRUD untuk manajemen penyewaan barang yang dibangun dengan Laravel dan Tailwind CSS.

## Fitur Utama

### 1. Autentikasi Admin
- Login dan registrasi admin
- Sistem autentikasi yang aman
- Logout otomatis

### 2. Manajemen Barang
- CRUD lengkap untuk barang
- Upload gambar barang
- Kategori barang (Elektronik, Peralatan, Kendaraan, Lainnya)
- Manajemen stok otomatis
- Harga sewa per hari

### 3. Manajemen Penyewa
- CRUD lengkap untuk penyewa
- Data lengkap (nama, alamat, telepon, email, identitas)
- Riwayat transaksi per penyewa

### 4. Manajemen Transaksi
- Pembuatan transaksi penyewaan
- Perhitungan biaya otomatis berdasarkan durasi
- Konfirmasi pengembalian barang
- Pencatatan kondisi barang dan denda
- Status transaksi (aktif/selesai)

### 5. Dashboard
- Statistik real-time
- Pendapatan hari ini dan bulan ini
- Transaksi terbaru
- Quick actions

## Teknologi yang Digunakan

- **Backend**: Laravel 12
- **Frontend**: Tailwind CSS
- **Database**: SQLite (default), bisa diubah ke MySQL/PostgreSQL
- **Authentication**: Laravel Breeze (built-in)
- **File Storage**: Laravel Storage

## Color Palette

Aplikasi menggunakan color palette yang konsisten:
- `#000F22` - Primary Dark
- `#052355` - Primary
- `#4B76A4` - Secondary
- `#4A719B` - Secondary Dark
- `#7393BC` - Accent
- `#C2E8FF` - Light

## Instalasi

### Prerequisites
- PHP 8.1+
- Composer
- Node.js (opsional, untuk Tailwind build)

### Langkah Instalasi

1. **Clone repository**
```bash
git clone <repository-url>
cd aplikasi-rental-barang
```

2. **Install dependencies**
```bash
composer install
```

3. **Setup environment**
```bash
cp .env.example .env
php artisan key:generate
```

4. **Setup database**
```bash
php artisan migrate
```

5. **Setup storage**
```bash
php artisan storage:link
```

6. **Jalankan server**
```bash
php artisan serve
```

7. **Akses aplikasi**
Buka browser dan kunjungi `http://localhost:8000`

## Struktur Database

### Tabel Users (Admin)
- `id` - Primary key
- `name` - Nama admin
- `email` - Email admin
- `password` - Password (hashed)
- `created_at`, `updated_at` - Timestamps

### Tabel Barang
- `id` - Primary key
- `nama` - Nama barang
- `kategori` - Kategori barang
- `harga_sewa` - Harga sewa per hari
- `stok` - Jumlah stok tersedia
- `deskripsi` - Deskripsi barang (opsional)
- `gambar` - Path gambar (opsional)
- `created_at`, `updated_at` - Timestamps

### Tabel Penyewa
- `id` - Primary key
- `nama` - Nama penyewa
- `alamat` - Alamat penyewa
- `no_telp` - Nomor telepon
- `email` - Email (opsional)
- `identitas` - Nomor KTP/SIM
- `created_at`, `updated_at` - Timestamps

### Tabel Transaksi
- `id` - Primary key
- `barang_id` - Foreign key ke tabel barang
- `penyewa_id` - Foreign key ke tabel penyewa
- `tgl_sewa` - Tanggal mulai sewa
- `tgl_kembali` - Tanggal kembali
- `total_biaya` - Total biaya sewa
- `status` - Status transaksi (aktif/selesai)
- `kondisi_barang` - Kondisi saat dikembalikan (baik/rusak)
- `denda` - Denda jika ada kerusakan
- `catatan` - Catatan tambahan
- `created_at`, `updated_at` - Timestamps

## Alur Kerja

### 1. Autentikasi Admin
1. Admin mengakses halaman login
2. Masukkan email dan password
3. Setelah login, diarahkan ke dashboard

### 2. Manajemen Barang
1. **Tambah Barang**: Admin mengisi form dengan data barang
2. **Edit Barang**: Admin dapat mengubah informasi barang
3. **Hapus Barang**: Konfirmasi sebelum menghapus
4. **Lihat Barang**: Detail lengkap barang dan riwayat transaksi

### 3. Manajemen Penyewa
1. **Tambah Penyewa**: Admin mendaftarkan penyewa baru
2. **Edit Penyewa**: Admin dapat mengubah data penyewa
3. **Hapus Penyewa**: Konfirmasi sebelum menghapus
4. **Lihat Penyewa**: Detail penyewa dan statistik transaksi

### 4. Proses Penyewaan
1. **Buat Transaksi**: Admin memilih barang dan penyewa
2. **Set Tanggal**: Tanggal sewa dan kembali
3. **Hitung Biaya**: Sistem menghitung otomatis
4. **Konfirmasi**: Admin konfirmasi transaksi
5. **Update Stok**: Stok barang berkurang otomatis

### 5. Pengembalian Barang
1. **Pilih Transaksi**: Admin memilih transaksi aktif
2. **Input Kondisi**: Kondisi barang saat dikembalikan
3. **Set Denda**: Jika ada kerusakan
4. **Konfirmasi**: Status berubah menjadi selesai
5. **Update Stok**: Stok barang bertambah otomatis

## API Endpoints

### Authentication
- `GET /login` - Halaman login
- `POST /login` - Proses login
- `GET /register` - Halaman registrasi
- `POST /register` - Proses registrasi
- `POST /logout` - Logout

### Dashboard
- `GET /dashboard` - Dashboard utama

### Barang
- `GET /barang` - Daftar barang
- `GET /barang/create` - Form tambah barang
- `POST /barang` - Simpan barang baru
- `GET /barang/{id}` - Detail barang
- `GET /barang/{id}/edit` - Form edit barang
- `PUT /barang/{id}` - Update barang
- `DELETE /barang/{id}` - Hapus barang

### Penyewa
- `GET /penyewa` - Daftar penyewa
- `GET /penyewa/create` - Form tambah penyewa
- `POST /penyewa` - Simpan penyewa baru
- `GET /penyewa/{id}` - Detail penyewa
- `GET /penyewa/{id}/edit` - Form edit penyewa
- `PUT /penyewa/{id}` - Update penyewa
- `DELETE /penyewa/{id}` - Hapus penyewa

### Transaksi
- `GET /transaksi` - Daftar transaksi
- `GET /transaksi/create` - Form buat transaksi
- `POST /transaksi` - Simpan transaksi baru
- `GET /transaksi/{id}` - Detail transaksi
- `GET /transaksi/{id}/edit` - Form edit transaksi
- `PUT /transaksi/{id}` - Update transaksi
- `DELETE /transaksi/{id}` - Hapus transaksi
- `POST /transaksi/{id}/konfirmasi-pengembalian` - Konfirmasi pengembalian

## Fitur Tambahan

### Search & Filter
- Pencarian barang berdasarkan nama
- Filter barang berdasarkan kategori
- Pencarian penyewa berdasarkan nama
- Filter transaksi berdasarkan status dan tanggal

### Responsive Design
- Mobile-friendly interface
- Responsive tables dan forms
- Touch-friendly buttons

### Security Features
- CSRF protection
- Input validation
- File upload validation
- Authentication middleware

## Deployment

### Production Setup
1. Set environment ke production
2. Optimize autoloader: `composer install --optimize-autoloader --no-dev`
3. Cache config: `php artisan config:cache`
4. Cache routes: `php artisan route:cache`
5. Cache views: `php artisan view:cache`

### Database Migration
```bash
php artisan migrate --force
```

## Troubleshooting

### Common Issues

1. **Storage link tidak berfungsi**
```bash
php artisan storage:link
```

2. **Permission denied**
```bash
chmod -R 755 storage bootstrap/cache
```

3. **Database connection error**
- Periksa konfigurasi database di `.env`
- Pastikan database sudah dibuat

4. **Composer autoload error**
```bash
composer dump-autoload
```

## Contributing

1. Fork repository
2. Buat feature branch
3. Commit changes
4. Push ke branch
5. Buat Pull Request

## License

Aplikasi ini dibuat untuk tujuan pembelajaran dan dapat digunakan secara bebas.

## Support

Untuk pertanyaan atau dukungan, silakan buat issue di repository ini.
