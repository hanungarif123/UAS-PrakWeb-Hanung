<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Transaksi;
use App\Models\Penyewa;
use Illuminate\Http\Request;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $totalBarang = Barang::count();
        $barangTersedia = Barang::where('stok', '>', 0)->count();
        $transaksiAktif = Transaksi::where('status', 'aktif')->count();
        $totalPenyewa = Penyewa::count();
        
        // Pendapatan hari ini
        $pendapatanHariIni = Transaksi::whereDate('created_at', Carbon::today())
            ->where('status', 'selesai')
            ->sum('total_biaya');
            
        // Pendapatan bulan ini
        $pendapatanBulanIni = Transaksi::whereMonth('created_at', Carbon::now()->month)
            ->whereYear('created_at', Carbon::now()->year)
            ->where('status', 'selesai')
            ->sum('total_biaya');

        // Transaksi terbaru
        $transaksiTerbaru = Transaksi::with(['barang', 'penyewa'])
            ->latest()
            ->take(5)
            ->get();

        return view('dashboard', compact(
            'totalBarang',
            'barangTersedia',
            'transaksiAktif',
            'totalPenyewa',
            'pendapatanHariIni',
            'pendapatanBulanIni',
            'transaksiTerbaru'
        ));
    }
}
