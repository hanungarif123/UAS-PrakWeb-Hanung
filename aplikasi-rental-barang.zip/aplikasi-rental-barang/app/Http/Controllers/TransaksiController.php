<?php

namespace App\Http\Controllers;

use App\Models\Barang;
use App\Models\Penyewa;
use App\Models\Transaksi;
use Illuminate\Http\Request;
use Carbon\Carbon;

class TransaksiController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $query = Transaksi::with(['barang', 'penyewa']);

        // Search functionality
        if ($request->filled('search')) {
            $query->whereHas('barang', function($q) use ($request) {
                $q->where('nama', 'like', '%' . $request->search . '%');
            })->orWhereHas('penyewa', function($q) use ($request) {
                $q->where('nama', 'like', '%' . $request->search . '%');
            });
        }

        // Filter by status
        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        // Filter by date
        if ($request->filled('date')) {
            $query->whereDate('tgl_sewa', $request->date);
        }

        $transaksi = $query->latest()->paginate(10);
        return view('transaksi.index', compact('transaksi'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $barang = Barang::where('stok', '>', 0)->get();
        $penyewa = Penyewa::all();
        return view('transaksi.create', compact('barang', 'penyewa'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'barang_id' => 'required|exists:barang,id',
            'penyewa_id' => 'required|exists:penyewa,id',
            'tgl_sewa' => 'required|date|after_or_equal:today',
            'tgl_kembali' => 'required|date|after:tgl_sewa',
            'catatan' => 'nullable|string'
        ]);

        $barang = Barang::findOrFail($request->barang_id);
        
        if ($barang->stok <= 0) {
            return back()->withErrors(['barang_id' => 'Stok barang tidak tersedia']);
        }

        $tglSewa = Carbon::parse($request->tgl_sewa);
        $tglKembali = Carbon::parse($request->tgl_kembali);
        $jumlahHari = $tglSewa->diffInDays($tglKembali) + 1;
        $totalBiaya = $barang->harga_sewa * $jumlahHari;

        $transaksi = Transaksi::create([
            'barang_id' => $request->barang_id,
            'penyewa_id' => $request->penyewa_id,
            'tgl_sewa' => $request->tgl_sewa,
            'tgl_kembali' => $request->tgl_kembali,
            'total_biaya' => $totalBiaya,
            'status' => 'aktif',
            'catatan' => $request->catatan
        ]);

        // Kurangi stok barang
        $barang->decrement('stok');

        return redirect()->route('transaksi.index')
            ->with('success', 'Transaksi berhasil dibuat');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $transaksi = Transaksi::with(['barang', 'penyewa'])->findOrFail($id);
        return view('transaksi.show', compact('transaksi'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $transaksi = Transaksi::findOrFail($id);
        $barang = Barang::all();
        $penyewa = Penyewa::all();
        return view('transaksi.edit', compact('transaksi', 'barang', 'penyewa'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'barang_id' => 'required|exists:barang,id',
            'penyewa_id' => 'required|exists:penyewa,id',
            'tgl_sewa' => 'required|date',
            'tgl_kembali' => 'required|date|after:tgl_sewa',
            'status' => 'required|in:aktif,selesai',
            'kondisi_barang' => 'nullable|in:baik,rusak',
            'denda' => 'nullable|numeric|min:0',
            'catatan' => 'nullable|string'
        ]);

        $transaksi = Transaksi::findOrFail($id);
        $barang = Barang::findOrFail($request->barang_id);

        $tglSewa = Carbon::parse($request->tgl_sewa);
        $tglKembali = Carbon::parse($request->tgl_kembali);
        $jumlahHari = $tglSewa->diffInDays($tglKembali) + 1;
        $totalBiaya = $barang->harga_sewa * $jumlahHari;

        // Jika status berubah dari aktif ke selesai, kembalikan stok
        if ($transaksi->status == 'aktif' && $request->status == 'selesai') {
            $barang->increment('stok');
        }

        $transaksi->update([
            'barang_id' => $request->barang_id,
            'penyewa_id' => $request->penyewa_id,
            'tgl_sewa' => $request->tgl_sewa,
            'tgl_kembali' => $request->tgl_kembali,
            'total_biaya' => $totalBiaya,
            'status' => $request->status,
            'kondisi_barang' => $request->kondisi_barang,
            'denda' => $request->denda ?? 0,
            'catatan' => $request->catatan
        ]);

        return redirect()->route('transaksi.index')
            ->with('success', 'Transaksi berhasil diperbarui');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $transaksi = Transaksi::findOrFail($id);
        
        // Jika transaksi masih aktif, kembalikan stok
        if ($transaksi->status == 'aktif') {
            $transaksi->barang->increment('stok');
        }

        $transaksi->delete();

        return redirect()->route('transaksi.index')
            ->with('success', 'Transaksi berhasil dihapus');
    }

    /**
     * Konfirmasi pengembalian barang
     */
    public function konfirmasiPengembalian(Request $request, string $id)
    {
        $request->validate([
            'kondisi_barang' => 'required|in:baik,rusak',
            'denda' => 'nullable|numeric|min:0',
            'catatan' => 'nullable|string'
        ]);

        $transaksi = Transaksi::findOrFail($id);
        
        if ($transaksi->status !== 'aktif') {
            return back()->withErrors(['status' => 'Transaksi sudah selesai']);
        }

        $transaksi->update([
            'status' => 'selesai',
            'kondisi_barang' => $request->kondisi_barang,
            'denda' => $request->denda ?? 0,
            'catatan' => $request->catatan
        ]);

        // Kembalikan stok barang
        $transaksi->barang->increment('stok');

        return redirect()->route('transaksi.index')
            ->with('success', 'Pengembalian barang berhasil dikonfirmasi');
    }
}
