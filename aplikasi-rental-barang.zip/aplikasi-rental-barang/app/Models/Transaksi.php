<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Transaksi extends Model
{
    protected $table = 'transaksi';
    
    protected $fillable = [
        'barang_id',
        'penyewa_id',
        'tgl_sewa',
        'tgl_kembali',
        'total_biaya',
        'status',
        'kondisi_barang',
        'denda',
        'catatan'
    ];

    protected $casts = [
        'tgl_sewa' => 'date',
        'tgl_kembali' => 'date',
        'total_biaya' => 'decimal:2',
        'denda' => 'decimal:2',
    ];

    public function barang(): BelongsTo
    {
        return $this->belongsTo(Barang::class);
    }

    public function penyewa(): BelongsTo
    {
        return $this->belongsTo(Penyewa::class);
    }
}
