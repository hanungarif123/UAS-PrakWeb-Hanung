<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Barang;
use App\Models\Penyewa;
use App\Models\Transaksi;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // Create admin user
        User::create([
            'name' => 'Admin Rental',
            'email' => 'admin@rental.com',
            'password' => Hash::make('password123'),
        ]);

        // Create sample barang
        $barang = [
            [
                'nama' => 'Laptop Asus ROG',
                'kategori' => 'Elektronik',
                'harga_sewa' => 150000,
                'stok' => 3,
                'deskripsi' => 'Laptop gaming dengan performa tinggi',
            ],
            [
                'nama' => 'Proyektor Epson',
                'kategori' => 'Elektronik',
                'harga_sewa' => 200000,
                'stok' => 2,
                'deskripsi' => 'Proyektor untuk presentasi',
            ],
            [
                'nama' => 'Mobil Avanza',
                'kategori' => 'Kendaraan',
                'harga_sewa' => 500000,
                'stok' => 1,
                'deskripsi' => 'Mobil keluarga 7 seat',
            ],
            [
                'nama' => 'Tenda Camping',
                'kategori' => 'Peralatan',
                'harga_sewa' => 75000,
                'stok' => 5,
                'deskripsi' => 'Tenda untuk camping outdoor',
            ],
            [
                'nama' => 'Sound System',
                'kategori' => 'Elektronik',
                'harga_sewa' => 300000,
                'stok' => 2,
                'deskripsi' => 'Sound system untuk acara',
            ],
        ];

        foreach ($barang as $item) {
            Barang::create($item);
        }

        // Create sample penyewa
        $penyewa = [
            [
                'nama' => 'Budi Santoso',
                'alamat' => 'Jl. Sudirman No. 123, Jakarta',
                'no_telp' => '08123456789',
                'email' => 'budi@email.com',
                'identitas' => '3171234567890123',
            ],
            [
                'nama' => 'Siti Rahma',
                'alamat' => 'Jl. Thamrin No. 456, Jakarta',
                'no_telp' => '08987654321',
                'email' => 'siti@email.com',
                'identitas' => '3171234567890124',
            ],
            [
                'nama' => 'Ahmad Fauzi',
                'alamat' => 'Jl. Gatot Subroto No. 789, Jakarta',
                'no_telp' => '08555123456',
                'email' => 'ahmad@email.com',
                'identitas' => '3171234567890125',
            ],
        ];

        foreach ($penyewa as $person) {
            Penyewa::create($person);
        }

        // Create sample transaksi
        $transaksi = [
            [
                'barang_id' => 1,
                'penyewa_id' => 1,
                'tgl_sewa' => now()->subDays(5),
                'tgl_kembali' => now()->addDays(2),
                'total_biaya' => 1050000,
                'status' => 'aktif',
                'catatan' => 'Untuk keperluan kerja',
            ],
            [
                'barang_id' => 2,
                'penyewa_id' => 2,
                'tgl_sewa' => now()->subDays(3),
                'tgl_kembali' => now()->addDays(1),
                'total_biaya' => 800000,
                'status' => 'aktif',
                'catatan' => 'Untuk presentasi kantor',
            ],
            [
                'barang_id' => 4,
                'penyewa_id' => 3,
                'tgl_sewa' => now()->subDays(10),
                'tgl_kembali' => now()->subDays(2),
                'total_biaya' => 600000,
                'status' => 'selesai',
                'kondisi_barang' => 'baik',
                'catatan' => 'Camping di Puncak',
            ],
        ];

        foreach ($transaksi as $transaction) {
            Transaksi::create($transaction);
        }
    }
}
