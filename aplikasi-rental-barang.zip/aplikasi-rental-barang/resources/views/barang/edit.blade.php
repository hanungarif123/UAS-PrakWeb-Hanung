@extends('layouts.app')

@section('title', 'Edit Barang - Aplikasi Rental Barang')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Edit Barang</h1>
        <p class="text-gray-600 mt-2">Edit informasi barang</p>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6">
        <form action="{{ route('barang.update', $barang->id) }}" method="POST" enctype="multipart/form-data">
            @csrf
            @method('PUT')
            
            <div class="space-y-6">
                <!-- Nama Barang -->
                <div>
                    <label for="nama" class="block text-sm font-medium text-gray-700">Nama Barang *</label>
                    <input type="text" name="nama" id="nama" required
                           value="{{ old('nama', $barang->nama) }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('nama')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Kategori -->
                <div>
                    <label for="kategori" class="block text-sm font-medium text-gray-700">Kategori *</label>
                    <select name="kategori" id="kategori" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="">Pilih Kategori</option>
                        <option value="Elektronik" {{ old('kategori', $barang->kategori) == 'Elektronik' ? 'selected' : '' }}>Elektronik</option>
                        <option value="Peralatan" {{ old('kategori', $barang->kategori) == 'Peralatan' ? 'selected' : '' }}>Peralatan</option>
                        <option value="Kendaraan" {{ old('kategori', $barang->kategori) == 'Kendaraan' ? 'selected' : '' }}>Kendaraan</option>
                        <option value="Lainnya" {{ old('kategori', $barang->kategori) == 'Lainnya' ? 'selected' : '' }}>Lainnya</option>
                    </select>
                    @error('kategori')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Harga Sewa -->
                <div>
                    <label for="harga_sewa" class="block text-sm font-medium text-gray-700">Harga Sewa per Hari *</label>
                    <div class="mt-1 relative rounded-md shadow-sm">
                        <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                            <span class="text-gray-500 sm:text-sm">Rp</span>
                        </div>
                        <input type="number" name="harga_sewa" id="harga_sewa" required min="0" step="1000"
                               value="{{ old('harga_sewa', $barang->harga_sewa) }}"
                               class="pl-12 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    </div>
                    @error('harga_sewa')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Stok -->
                <div>
                    <label for="stok" class="block text-sm font-medium text-gray-700">Stok *</label>
                    <input type="number" name="stok" id="stok" required min="0"
                           value="{{ old('stok', $barang->stok) }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('stok')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Deskripsi -->
                <div>
                    <label for="deskripsi" class="block text-sm font-medium text-gray-700">Deskripsi</label>
                    <textarea name="deskripsi" id="deskripsi" rows="4"
                              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">{{ old('deskripsi', $barang->deskripsi) }}</textarea>
                    @error('deskripsi')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Gambar -->
                <div>
                    <label for="gambar" class="block text-sm font-medium text-gray-700">Gambar</label>
                    
                    @if($barang->gambar)
                        <div class="mt-2 mb-4">
                            <img src="{{ asset('storage/barang/' . $barang->gambar) }}" 
                                 alt="{{ $barang->nama }}" 
                                 class="h-32 w-32 object-cover rounded-lg">
                            <p class="text-sm text-gray-500 mt-1">Gambar saat ini</p>
                        </div>
                    @endif
                    
                    <input type="file" name="gambar" id="gambar" accept="image/*"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    <p class="mt-1 text-sm text-gray-500">Format: JPG, PNG, GIF. Maksimal 2MB. Kosongkan jika tidak ingin mengubah gambar.</p>
                    @error('gambar')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Buttons -->
                <div class="flex justify-end space-x-3 pt-6">
                    <a href="{{ route('barang.index') }}" 
                       class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition duration-200">
                        Batal
                    </a>
                    <button type="submit" 
                            class="bg-gradient-secondary text-white px-4 py-2 rounded-md hover:bg-primary-300 transition duration-200">
                        Update Barang
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection 