@extends('layouts.app')

@section('title', 'Daftar Penyewa - Aplikasi Rental Barang')

@section('content')
<div class="space-y-6">
    <!-- Header -->
    <div class="flex justify-between items-center">
        <div>
            <h1 class="text-3xl font-bold text-gray-900">Daftar Penyewa</h1>
            <p class="text-gray-600 mt-2">Kelola data penyewa yang terdaftar</p>
        </div>
        <a href="{{ route('penyewa.create') }}" class="bg-gradient-secondary text-white px-4 py-2 rounded-lg hover:bg-primary-300 transition duration-200">
            <div class="flex items-center">
                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"></path>
                </svg>
                Tambah Penyewa
            </div>
        </a>
    </div>

    <!-- Search -->
    <div class="bg-white rounded-lg shadow-md p-6">
        <form method="GET" action="{{ route('penyewa.index') }}" class="flex gap-4">
            <div class="flex-1">
                <input type="text" name="search" placeholder="Cari penyewa..." 
                       value="{{ request('search') }}"
                       class="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-300">
            </div>
            <button type="submit" class="bg-primary-400 text-white px-4 py-2 rounded-md hover:bg-primary-500">
                Cari
            </button>
        </form>
    </div>

    <!-- Penyewa Table -->
    <div class="bg-white rounded-lg shadow-md overflow-hidden">
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nama</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Alamat</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Kontak</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Identitas</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Aksi</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($penyewa as $item)
                    <tr class="hover:bg-gray-50">
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900">{{ $item->nama }}</div>
                        </td>
                        <td class="px-6 py-4">
                            <div class="text-sm text-gray-900 max-w-xs truncate">{{ $item->alamat }}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">{{ $item->no_telp }}</div>
                            @if($item->email)
                                <div class="text-sm text-gray-500">{{ $item->email }}</div>
                            @endif
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">{{ $item->identitas }}</div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                            <div class="flex space-x-2">
                                <a href="{{ route('penyewa.show', $item->id) }}" 
                                   class="text-blue-600 hover:text-blue-900">Lihat</a>
                                <a href="{{ route('penyewa.edit', $item->id) }}" 
                                   class="text-green-600 hover:text-green-900">Edit</a>
                                <form action="{{ route('penyewa.destroy', $item->id) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" 
                                            onclick="return confirm('Apakah Anda yakin ingin menghapus penyewa ini?')"
                                            class="text-red-600 hover:text-red-900">Hapus</button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                            Belum ada penyewa yang ditambahkan
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        
        <!-- Pagination -->
        @if($penyewa->hasPages())
        <div class="bg-white px-4 py-3 border-t border-gray-200 sm:px-6">
            {{ $penyewa->links('pagination::tailwind') }}
        </div>
        @endif
    </div>
</div>
@endsection 