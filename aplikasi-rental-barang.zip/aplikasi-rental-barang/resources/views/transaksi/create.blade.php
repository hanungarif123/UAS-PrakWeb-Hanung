@extends('layouts.app')

@section('title', 'Buat Transaksi - Aplikasi Rental Barang')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Buat Transaksi Baru</h1>
        <p class="text-gray-600 mt-2">Buat transaksi penyewaan baru</p>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6">
        <form action="{{ route('transaksi.store') }}" method="POST">
            @csrf
            
            <div class="space-y-6">
                <!-- Barang -->
                <div>
                    <label for="barang_id" class="block text-sm font-medium text-gray-700">Pilih Barang *</label>
                    <select name="barang_id" id="barang_id" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="">Pilih Barang</option>
                        @foreach($barang as $item)
                            <option value="{{ $item->id }}" 
                                    data-harga="{{ $item->harga_sewa }}"
                                    {{ old('barang_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->nama }} - Rp {{ number_format($item->harga_sewa, 0, ',', '.') }}/hari (Stok: {{ $item->stok }})
                            </option>
                        @endforeach
                    </select>
                    @error('barang_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Penyewa -->
                <div>
                    <label for="penyewa_id" class="block text-sm font-medium text-gray-700">Pilih Penyewa *</label>
                    <select name="penyewa_id" id="penyewa_id" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="">Pilih Penyewa</option>
                        @foreach($penyewa as $item)
                            <option value="{{ $item->id }}" {{ old('penyewa_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->nama }} - {{ $item->no_telp }}
                            </option>
                        @endforeach
                    </select>
                    @error('penyewa_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Tanggal Sewa -->
                <div>
                    <label for="tgl_sewa" class="block text-sm font-medium text-gray-700">Tanggal Sewa *</label>
                    <input type="date" name="tgl_sewa" id="tgl_sewa" required
                           value="{{ old('tgl_sewa', date('Y-m-d')) }}"
                           min="{{ date('Y-m-d') }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('tgl_sewa')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Tanggal Kembali -->
                <div>
                    <label for="tgl_kembali" class="block text-sm font-medium text-gray-700">Tanggal Kembali *</label>
                    <input type="date" name="tgl_kembali" id="tgl_kembali" required
                           value="{{ old('tgl_kembali') }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('tgl_kembali')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Preview Total Biaya -->
                <div id="totalPreview" class="hidden">
                    <div class="bg-blue-50 border border-blue-200 rounded-md p-4">
                        <h4 class="text-sm font-medium text-blue-800">Preview Biaya</h4>
                        <div class="mt-2 space-y-1">
                            <div class="flex justify-between text-sm">
                                <span class="text-blue-600">Harga per hari:</span>
                                <span id="hargaPerHari" class="text-blue-900">Rp 0</span>
                            </div>
                            <div class="flex justify-between text-sm">
                                <span class="text-blue-600">Jumlah hari:</span>
                                <span id="jumlahHari" class="text-blue-900">0 hari</span>
                            </div>
                            <div class="flex justify-between text-sm font-medium">
                                <span class="text-blue-800">Total biaya:</span>
                                <span id="totalBiaya" class="text-blue-900">Rp 0</span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Catatan -->
                <div>
                    <label for="catatan" class="block text-sm font-medium text-gray-700">Catatan</label>
                    <textarea name="catatan" id="catatan" rows="3"
                              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">{{ old('catatan') }}</textarea>
                    @error('catatan')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Buttons -->
                <div class="flex justify-end space-x-3 pt-6">
                    <a href="{{ route('transaksi.index') }}" 
                       class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition duration-200">
                        Batal
                    </a>
                    <button type="submit" 
                            class="bg-gradient-secondary text-white px-4 py-2 rounded-md hover:bg-primary-300 transition duration-200">
                        Buat Transaksi
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const barangSelect = document.getElementById('barang_id');
    const tglSewa = document.getElementById('tgl_sewa');
    const tglKembali = document.getElementById('tgl_kembali');
    const totalPreview = document.getElementById('totalPreview');
    const hargaPerHari = document.getElementById('hargaPerHari');
    const jumlahHari = document.getElementById('jumlahHari');
    const totalBiaya = document.getElementById('totalBiaya');

    function calculateTotal() {
        const selectedOption = barangSelect.options[barangSelect.selectedIndex];
        const tglSewaValue = tglSewa.value;
        const tglKembaliValue = tgl_kembali.value;

        if (selectedOption && selectedOption.dataset.harga && tglSewaValue && tglKembaliValue) {
            const harga = parseInt(selectedOption.dataset.harga);
            const startDate = new Date(tglSewaValue);
            const endDate = new Date(tglKembaliValue);
            const days = Math.ceil((endDate - startDate) / (1000 * 60 * 60 * 24)) + 1;
            const total = harga * days;

            if (days > 0) {
                hargaPerHari.textContent = `Rp ${harga.toLocaleString('id-ID')}`;
                jumlahHari.textContent = `${days} hari`;
                totalBiaya.textContent = `Rp ${total.toLocaleString('id-ID')}`;
                totalPreview.classList.remove('hidden');
            } else {
                totalPreview.classList.add('hidden');
            }
        } else {
            totalPreview.classList.add('hidden');
        }
    }

    barangSelect.addEventListener('change', calculateTotal);
    tglSewa.addEventListener('change', calculateTotal);
    tglKembali.addEventListener('change', calculateTotal);
});
</script>
@endsection 