@extends('layouts.app')

@section('title', 'Edit Transaksi - Aplikasi Rental Barang')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="mb-6">
        <h1 class="text-3xl font-bold text-gray-900">Edit Transaksi</h1>
        <p class="text-gray-600 mt-2">Edit informasi transaksi</p>
    </div>

    <div class="bg-white rounded-lg shadow-md p-6">
        <form action="{{ route('transaksi.update', $transaksi->id) }}" method="POST">
            @csrf
            @method('PUT')
            
            <div class="space-y-6">
                <!-- Barang -->
                <div>
                    <label for="barang_id" class="block text-sm font-medium text-gray-700">Pilih Barang *</label>
                    <select name="barang_id" id="barang_id" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="">Pilih Barang</option>
                        @foreach($barang as $item)
                            <option value="{{ $item->id }}" 
                                    data-harga="{{ $item->harga_sewa }}"
                                    {{ old('barang_id', $transaksi->barang_id) == $item->id ? 'selected' : '' }}>
                                {{ $item->nama }} - Rp {{ number_format($item->harga_sewa, 0, ',', '.') }}/hari (Stok: {{ $item->stok }})
                            </option>
                        @endforeach
                    </select>
                    @error('barang_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Penyewa -->
                <div>
                    <label for="penyewa_id" class="block text-sm font-medium text-gray-700">Pilih Penyewa *</label>
                    <select name="penyewa_id" id="penyewa_id" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="">Pilih Penyewa</option>
                        @foreach($penyewa as $item)
                            <option value="{{ $item->id }}" {{ old('penyewa_id', $transaksi->penyewa_id) == $item->id ? 'selected' : '' }}>
                                {{ $item->nama }} - {{ $item->no_telp }}
                            </option>
                        @endforeach
                    </select>
                    @error('penyewa_id')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Tanggal Sewa -->
                <div>
                    <label for="tgl_sewa" class="block text-sm font-medium text-gray-700">Tanggal Sewa *</label>
                    <input type="date" name="tgl_sewa" id="tgl_sewa" required
                           value="{{ old('tgl_sewa', $transaksi->tgl_sewa->format('Y-m-d')) }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('tgl_sewa')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Tanggal Kembali -->
                <div>
                    <label for="tgl_kembali" class="block text-sm font-medium text-gray-700">Tanggal Kembali *</label>
                    <input type="date" name="tgl_kembali" id="tgl_kembali" required
                           value="{{ old('tgl_kembali', $transaksi->tgl_kembali->format('Y-m-d')) }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('tgl_kembali')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Status -->
                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700">Status *</label>
                    <select name="status" id="status" required
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="aktif" {{ old('status', $transaksi->status) == 'aktif' ? 'selected' : '' }}>Aktif</option>
                        <option value="selesai" {{ old('status', $transaksi->status) == 'selesai' ? 'selected' : '' }}>Selesai</option>
                    </select>
                    @error('status')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Kondisi Barang -->
                <div>
                    <label for="kondisi_barang" class="block text-sm font-medium text-gray-700">Kondisi Barang</label>
                    <select name="kondisi_barang" id="kondisi_barang"
                            class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                        <option value="">Pilih Kondisi</option>
                        <option value="baik" {{ old('kondisi_barang', $transaksi->kondisi_barang) == 'baik' ? 'selected' : '' }}>Baik</option>
                        <option value="rusak" {{ old('kondisi_barang', $transaksi->kondisi_barang) == 'rusak' ? 'selected' : '' }}>Rusak</option>
                    </select>
                    @error('kondisi_barang')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Denda -->
                <div>
                    <label for="denda" class="block text-sm font-medium text-gray-700">Denda</label>
                    <input type="number" name="denda" id="denda" min="0" step="1000"
                           value="{{ old('denda', $transaksi->denda) }}"
                           class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">
                    @error('denda')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Catatan -->
                <div>
                    <label for="catatan" class="block text-sm font-medium text-gray-700">Catatan</label>
                    <textarea name="catatan" id="catatan" rows="3"
                              class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-primary-300 focus:border-primary-300">{{ old('catatan', $transaksi->catatan) }}</textarea>
                    @error('catatan')
                        <p class="mt-1 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Buttons -->
                <div class="flex justify-end space-x-3 pt-6">
                    <a href="{{ route('transaksi.index') }}" 
                       class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md hover:bg-gray-400 transition duration-200">
                        Batal
                    </a>
                    <button type="submit" 
                            class="bg-gradient-secondary text-white px-4 py-2 rounded-md hover:bg-primary-300 transition duration-200">
                        Update Transaksi
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
@endsection 