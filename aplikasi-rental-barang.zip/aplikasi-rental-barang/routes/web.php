<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\BarangController;
use App\Http\Controllers\PenyewaController;
use App\Http\Controllers\TransaksiController;

// Authentication Routes
Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
Route::post('/register', [AuthController::class, 'register']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// Protected Routes
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // Barang Routes
    Route::resource('barang', BarangController::class);
    
    // Penyewa Routes
    Route::resource('penyewa', PenyewaController::class);
    
    // Transaksi Routes
    Route::resource('transaksi', TransaksiController::class);
    Route::post('/transaksi/{id}/konfirmasi-pengembalian', [TransaksiController::class, 'konfirmasiPengembalian'])
        ->name('transaksi.konfirmasi-pengembalian');
});

// Redirect root to dashboard if authenticated, otherwise to login
Route::get('/', function () {
    if (Auth::check()) {
        return redirect('/dashboard');
    }
    return redirect('/login');
});
