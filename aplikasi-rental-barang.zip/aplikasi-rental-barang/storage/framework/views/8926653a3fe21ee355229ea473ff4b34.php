

<?php $__env->startSection('title', 'Detail Transaksi - Aplikasi Rental Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="mb-6">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-900">Transaksi #<?php echo e($transaksi->id); ?></h1>
                <p class="text-gray-600 mt-2">Detail transaksi penyewaan</p>
            </div>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('transaksi.edit', $transaksi->id)); ?>" 
                   class="bg-gradient-secondary text-white px-4 py-2 rounded-lg hover:bg-primary-300 transition duration-200">
                    Edit Transaksi
                </a>
                <a href="<?php echo e(route('transaksi.index')); ?>" 
                   class="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition duration-200">
                    Kembali
                </a>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Transaction Details -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Informasi Transaksi</h3>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Status</label>
                    <?php if($transaksi->status == 'aktif'): ?>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-800">
                            Aktif
                        </span>
                    <?php else: ?>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                            Selesai
                        </span>
                    <?php endif; ?>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Tanggal Sewa</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->tgl_sewa->format('d/m/Y')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Tanggal Kembali</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->tgl_kembali->format('d/m/Y')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Total Biaya</label>
                    <p class="mt-1 text-lg font-semibold text-gray-900">Rp <?php echo e(number_format($transaksi->total_biaya, 0, ',', '.')); ?></p>
                </div>

                <?php if($transaksi->denda > 0): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Denda</label>
                    <p class="mt-1 text-lg font-semibold text-red-600">Rp <?php echo e(number_format($transaksi->denda, 0, ',', '.')); ?></p>
                </div>
                <?php endif; ?>

                <?php if($transaksi->kondisi_barang): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Kondisi Barang</label>
                    <?php if($transaksi->kondisi_barang == 'baik'): ?>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                            Baik
                        </span>
                    <?php else: ?>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                            Rusak
                        </span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <?php if($transaksi->catatan): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Catatan</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->catatan); ?></p>
                </div>
                <?php endif; ?>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Tanggal Dibuat</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->created_at->format('d/m/Y H:i')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Terakhir Diupdate</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->updated_at->format('d/m/Y H:i')); ?></p>
                </div>
            </div>
        </div>

        <!-- Barang & Penyewa Details -->
        <div class="space-y-6">
            <!-- Barang Details -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Informasi Barang</h3>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nama Barang</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->barang->nama); ?></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Kategori</label>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                            <?php echo e($transaksi->barang->kategori); ?>

                        </span>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Harga Sewa per Hari</label>
                        <p class="mt-1 text-sm text-gray-900">Rp <?php echo e(number_format($transaksi->barang->harga_sewa, 0, ',', '.')); ?></p>
                    </div>

                    <?php if($transaksi->barang->deskripsi): ?>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Deskripsi</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->barang->deskripsi); ?></p>
                    </div>
                    <?php endif; ?>

                    <div>
                        <a href="<?php echo e(route('barang.show', $transaksi->barang->id)); ?>" 
                           class="text-blue-600 hover:text-blue-900 text-sm">Lihat detail barang →</a>
                    </div>
                </div>
            </div>

            <!-- Penyewa Details -->
            <div class="bg-white rounded-lg shadow-md p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Informasi Penyewa</h3>
                
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nama Penyewa</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->penyewa->nama); ?></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Alamat</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->penyewa->alamat); ?></p>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nomor Telepon</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->penyewa->no_telp); ?></p>
                    </div>

                    <?php if($transaksi->penyewa->email): ?>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Email</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->penyewa->email); ?></p>
                    </div>
                    <?php endif; ?>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Nomor Identitas</label>
                        <p class="mt-1 text-sm text-gray-900"><?php echo e($transaksi->penyewa->identitas); ?></p>
                    </div>

                    <div>
                        <a href="<?php echo e(route('penyewa.show', $transaksi->penyewa->id)); ?>" 
                           class="text-blue-600 hover:text-blue-900 text-sm">Lihat detail penyewa →</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Action Buttons -->
    <?php if($transaksi->status == 'aktif'): ?>
    <div class="mt-6 bg-white rounded-lg shadow-md p-6">
        <h3 class="text-lg font-semibold text-gray-900 mb-4">Aksi</h3>
        <div class="flex space-x-3">
            <button onclick="showReturnModal()" 
                    class="bg-orange-500 text-white px-4 py-2 rounded-md hover:bg-orange-600 transition duration-200">
                Konfirmasi Pengembalian
            </button>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Return Modal -->
<?php if($transaksi->status == 'aktif'): ?>
<div id="returnModal" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full hidden">
    <div class="relative top-20 mx-auto p-5 border w-96 shadow-lg rounded-md bg-white">
        <div class="mt-3">
            <h3 class="text-lg font-medium text-gray-900 mb-4">Konfirmasi Pengembalian</h3>
            <form action="<?php echo e(route('transaksi.konfirmasi-pengembalian', $transaksi->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Kondisi Barang *</label>
                        <select name="kondisi_barang" required class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md">
                            <option value="">Pilih Kondisi</option>
                            <option value="baik">Baik</option>
                            <option value="rusak">Rusak</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Denda (opsional)</label>
                        <input type="number" name="denda" min="0" step="1000" 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md">
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-700">Catatan</label>
                        <textarea name="catatan" rows="3" 
                                  class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md"></textarea>
                    </div>
                </div>
                <div class="flex justify-end space-x-3 mt-6">
                    <button type="button" onclick="hideReturnModal()" 
                            class="bg-gray-300 text-gray-700 px-4 py-2 rounded-md">Batal</button>
                    <button type="submit" 
                            class="bg-gradient-secondary text-white px-4 py-2 rounded-md">Konfirmasi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function showReturnModal() {
    document.getElementById('returnModal').classList.remove('hidden');
}

function hideReturnModal() {
    document.getElementById('returnModal').classList.add('hidden');
}
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Msi-Modern\Aplikasi Penyewaan Barang\aplikasi-rental-barang\resources\views/transaksi/show.blade.php ENDPATH**/ ?>