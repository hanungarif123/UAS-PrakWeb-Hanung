<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title', 'Aplikasi Rental Barang'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#C2E8FF',
                            100: '#7393BC',
                            200: '#4A719B',
                            300: '#4B76A4',
                            400: '#052355',
                            500: '#000F22',
                        }
                    }
                }
            }
        }
    </script>
    <style>
        .bg-gradient-primary {
            background: linear-gradient(135deg, #000F22 0%, #052355 100%);
        }
        .bg-gradient-secondary {
            background: linear-gradient(135deg, #4B76A4 0%, #7393BC 100%);
        }
    </style>
    <!-- Material Icons CDN (optional, for icons) -->
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
</head>
<body class="bg-gray-50 min-h-screen flex">
    <?php if(auth()->guard()->check()): ?>
    <!-- Sidebar -->
    <aside class="w-64 bg-white shadow-md h-screen fixed flex flex-col">
        <div class="p-6 font-bold text-xl text-blue-600 border-b">
            Rental Barang
        </div>
        <nav class="flex-1 p-4">
            <ul class="space-y-2">
                <li>
                    <a href="<?php echo e(route('dashboard')); ?>" class="flex items-center p-2 rounded hover:bg-blue-100 text-gray-700">
                        <span class="material-icons mr-2">dashboard</span>
                        Dashboard
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('barang.index')); ?>" class="flex items-center p-2 rounded hover:bg-blue-100 text-gray-700">
                        <span class="material-icons mr-2">inventory_2</span>
                        Barang
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('penyewa.index')); ?>" class="flex items-center p-2 rounded hover:bg-blue-100 text-gray-700">
                        <span class="material-icons mr-2">people</span>
                        Penyewa
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('transaksi.index')); ?>" class="flex items-center p-2 rounded hover:bg-blue-100 text-gray-700">
                        <span class="material-icons mr-2">receipt_long</span>
                        Transaksi
                    </a>
                </li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="w-full flex items-center p-2 rounded hover:bg-red-100 text-red-600">
                            <span class="material-icons mr-2">logout</span>
                            Logout
                        </button>
                    </form>
                </li>
            </ul>
        </nav>
        <div class="p-4 border-t text-xs text-gray-400"><?php echo e(Auth::user()->name); ?></div>
    </aside>
    <?php endif; ?>

    <!-- Main Content -->
    <div class="flex-1 <?php if(auth()->guard()->check()): ?> ml-64 <?php endif; ?>">
        <main class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
            <?php if(session('success')): ?>
                <div class="mb-4 bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            <?php if(isset($errors) && $errors->any()): ?>
                <div class="mb-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>

        <!-- Footer -->
        <footer class="bg-gradient-primary text-white py-4 mt-8">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
                <p>&copy; <?php echo e(date('Y')); ?> Aplikasi Rental Barang. All rights reserved.</p>
            </div>
        </footer>
    </div>
</body>
</html> <?php /**PATH C:\Users\Msi-Modern\Aplikasi Penyewaan Barang\aplikasi-rental-barang\resources\views/layouts/app.blade.php ENDPATH**/ ?>