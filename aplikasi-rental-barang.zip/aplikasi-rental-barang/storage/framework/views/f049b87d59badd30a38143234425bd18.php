

<?php $__env->startSection('title', 'Detail Barang - Aplikasi Rental Barang'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="mb-6">
        <div class="flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-bold text-gray-900"><?php echo e($barang->nama); ?></h1>
                <p class="text-gray-600 mt-2">Detail informasi barang</p>
            </div>
            <div class="flex space-x-3">
                <a href="<?php echo e(route('barang.edit', $barang->id)); ?>" 
                   class="bg-gradient-secondary text-white px-4 py-2 rounded-lg hover:bg-primary-300 transition duration-200">
                    Edit Barang
                </a>
                <a href="<?php echo e(route('barang.index')); ?>" 
                   class="bg-gray-300 text-gray-700 px-4 py-2 rounded-lg hover:bg-gray-400 transition duration-200">
                    Kembali
                </a>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Image Section -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Gambar Barang</h3>
            <?php if($barang->gambar): ?>
                <img src="<?php echo e($barang->gambar ? asset('storage/barang/' . $barang->gambar) : asset('images/default.png')); ?>" 
                     alt="<?php echo e($barang->nama); ?>" 
                     class="w-full h-64 object-cover rounded-lg">
                <div class="text-xs text-gray-400"><?php echo e($barang->gambar); ?></div>
            <?php else: ?>
                <div class="w-full h-64 bg-gray-200 rounded-lg flex items-center justify-center">
                    <div class="text-center">
                        <svg class="w-16 h-16 text-gray-400 mx-auto mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                        </svg>
                        <p class="text-gray-500">Tidak ada gambar</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Details Section -->
        <div class="bg-white rounded-lg shadow-md p-6">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Informasi Barang</h3>
            
            <div class="space-y-4">
                <div>
                    <label class="block text-sm font-medium text-gray-700">Nama Barang</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($barang->nama); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Kategori</label>
                    <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-800">
                        <?php echo e($barang->kategori); ?>

                    </span>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Harga Sewa per Hari</label>
                    <p class="mt-1 text-sm text-gray-900 font-semibold">Rp <?php echo e(number_format($barang->harga_sewa, 0, ',', '.')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Stok</label>
                    <?php if($barang->stok > 0): ?>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                            <?php echo e($barang->stok); ?> tersedia
                        </span>
                    <?php else: ?>
                        <span class="mt-1 inline-flex px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                            Habis
                        </span>
                    <?php endif; ?>
                </div>

                <?php if($barang->deskripsi): ?>
                <div>
                    <label class="block text-sm font-medium text-gray-700">Deskripsi</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($barang->deskripsi); ?></p>
                </div>
                <?php endif; ?>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Tanggal Dibuat</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($barang->created_at->format('d/m/Y H:i')); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700">Terakhir Diupdate</label>
                    <p class="mt-1 text-sm text-gray-900"><?php echo e($barang->updated_at->format('d/m/Y H:i')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Transaksi History -->
    <div class="mt-6 bg-white rounded-lg shadow-md">
        <div class="px-6 py-4 border-b border-gray-200">
            <h3 class="text-lg font-semibold text-gray-900">Riwayat Transaksi</h3>
        </div>
        <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Penyewa</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Sewa</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tanggal Kembali</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__empty_1 = true; $__currentLoopData = $barang->transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaksi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm font-medium text-gray-900"><?php echo e($transaksi->penyewa->nama); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo e($transaksi->tgl_sewa->format('d/m/Y')); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900"><?php echo e($transaksi->tgl_kembali->format('d/m/Y')); ?></div>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <?php if($transaksi->status == 'aktif'): ?>
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-yellow-100 text-yellow-800">
                                    Aktif
                                </span>
                            <?php else: ?>
                                <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
                                    Selesai
                                </span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 whitespace-nowrap">
                            <div class="text-sm text-gray-900">Rp <?php echo e(number_format($transaksi->total_biaya, 0, ',', '.')); ?></div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                            Belum ada transaksi untuk barang ini
                        </td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Msi-Modern\Aplikasi Penyewaan Barang\aplikasi-rental-barang\resources\views/barang/show.blade.php ENDPATH**/ ?>